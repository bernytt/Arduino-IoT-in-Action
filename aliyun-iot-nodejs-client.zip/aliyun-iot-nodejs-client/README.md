
### 1.安装Nodejs环境
选择最新LTS版即可 https://nodejs.org

### 2.设备身份
替换iot-device-config.js中的设备身份信息

### 3.在CLI启动脚本
启动命令: node aliyun-iot-client.js 



微信公众号: IoT物联网技术