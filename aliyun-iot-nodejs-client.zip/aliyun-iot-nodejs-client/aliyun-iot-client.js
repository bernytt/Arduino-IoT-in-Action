/**
 * 启动模拟设备: node aliyun-iot-client.js 
 * 
 * 'dependencies': { 'mqtt': '2.18.8' }
*/
const crypto = require('crypto');
const mqtt = require('mqtt');
//设备身份信息
const deviceConfig = require('./iot-device-config.js');

//根据三元组生成mqtt连接参数
const options = initMqttOptions(deviceConfig);
const url = `tcp://${deviceConfig.productKey}.iot-as-mqtt.${deviceConfig.regionId}.aliyuncs.com:1883`;

//2.建立连接
const client = mqtt.connect(url, options);

//3.属性数据上报
const topic = `/sys/${deviceConfig.productKey}/${deviceConfig.deviceName}/thing/event/property/post`;
// 5s上报一次模拟数据
setInterval(function() {
    //发布数据到topic
    client.publish(topic, getPostData());
}, 5 * 1000);


/*
 * IoT平台mqtt连接参数初始化
*/
function initMqttOptions(deviceConfig) {

    const params = {
        productKey: deviceConfig.productKey,
        deviceName: deviceConfig.deviceName,
        timestamp: Date.now(),
        clientId: Math.random().toString(36).substr(2),
    }
    //CONNECT参数
    const options = {
        keepalive: 60, //60s 心跳
        clean: false, //cleanSession 保持持久会话
        protocolVersion: 4 //MQTT v3.1.1
    }
    //1.生成clientId，username，password
    options.password = signHmacSha1(params, deviceConfig.deviceSecret);
    options.clientId = `${params.clientId}|securemode=3,signmethod=hmacsha1,timestamp=${params.timestamp}|`;
    options.username = `${params.deviceName}&${params.productKey}`;

    return options;
}

/*
 * 生成符合物模型功能定义的模拟数据
*/
function getPostData() {
    const payloadJson = {
        id: Date.now(),
        params: {
            temperature: Math.floor((Math.random() * 20) + 10),
            humidity: Math.floor((Math.random() * 20) + 60)
        },
        method: 'thing.event.property.post'
    }

    console.log('\n=== post IoT JSON Data ===\n topic=' + topic +'\n payload=',payloadJson)
    
    return JSON.stringify(payloadJson);
}

/*
 * 生成基于HmacSha1的password
 * 参考文档：https://help.aliyun.com/document_detail/73742.html?#h2-url-1
*/
function signHmacSha1(params, deviceSecret) {

    let keys = Object.keys(params).sort();
    // 按字典序排序
    keys = keys.sort();
    const list = [];
    keys.map((key) => {
        list.push(`${key}${params[key]}`);
    });
    const contentStr = list.join('');
    return crypto.createHmac('sha1', deviceSecret).update(contentStr).digest('hex');
}