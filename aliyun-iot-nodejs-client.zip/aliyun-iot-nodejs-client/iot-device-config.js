module.exports = {
    productKey: "替换productKey",
    deviceName: "替换deviceName",
    deviceSecret: "替换deviceSecret",
    regionId: "cn-shanghai"
}